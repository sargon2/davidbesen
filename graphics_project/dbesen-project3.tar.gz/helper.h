
#ifndef HELPER_H
#define HELPER_H

float my_rand(float low, float high);
float* getRandomVector();

#endif
